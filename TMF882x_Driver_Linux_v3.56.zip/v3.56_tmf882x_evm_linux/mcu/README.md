To run the mcu_tmf8820 bare metal driver you must first remove the linux kernel driver from the raspberry pi EVM:
1.	comment out the tof device tree from /boot/config.txt
a.	dtoverlay=tmf882x-overlay --> #dtoverlay=tmf882x-overlay
2.	add ‘i2c-dev’ to /etc/modules
3.	sync && reboot
4.	Run ./mcu_tmf882x –h  to display the help screen for running the bare metal driver
