#!/bin/bash
# Linux commands
#
# make sure all the following files are in the current directory
# tmf882x.ko tmf8801-overlay.dtbo
# libtof.so tofguimodule.so tof_userapp
# this script run with su privilege.
#
set -e
# Setup the auto installer service
if [  -f ./ams_installer.zip ]
then
    echo "Setting up auto installer service..."
    unzip -o ./ams_installer.zip
    ./ams_installer/install.sh
else
    echo "No ams_installer.zip file exit script"
    exit 1
fi
#
# change 8820 to 882x
sed -i 's/dtoverlay=tmf8820-overlay/dtoverlay=tmf882x-overlay/g' /boot/config.txt
if grep -q "dtoverlay=tmf882x-overlay" /boot/config.txt
then
    echo "..."
else
    echo "Append dtoverlay=tmf882x-overlay to /boot/config.txt"
    echo "dtoverlay=tmf882x-overlay" >> /boot/config.txt
fi
#
cp tmf882x.ko /opt/USBSensorBridgeRuntime/modules/
#
# Default to 8x8. the 4x4 file name is tmf8x2x_application_4x4.hex
cp -f tmf8x2x_application_8x8.hex /lib/firmware/tmf882x_firmware.bin
cp -f tmf882x-overlay.dtbo /boot/overlays/
cp -f tmf882x-overlay-fpc.dtbo /boot/overlays/
cp -f libtof.so /usr/lib/
cp -f tofguimodule.so /opt/USBSensorBridgeRuntime/modules/
cp -f ams-commanager-daemon.service /lib/systemd/system/
rm -rf /home/ams/aos_tmf8820_utils
cp -Rfp aos_tmf8820_utils /home/ams
cp -f EVM.VERSION /home/ams/
cp -f dhcpcd.exit-hook /etc
# copy GR/HPD
cp -f aos_tmf8820_utils/HPD_GR_runner/bin_package/* /usr/lib/
echo "modules/tmf882x.ko" > /opt/USBSensorBridgeRuntime/config/default_driver.config
echo "modules/tofguimodule.so" > /opt/USBSensorBridgeRuntime/config/default_module.config
if [  -f libtofalg.so ]
then
    echo "Copy libtofalg.so to /usr/lib/"
    cp -f libtofalg.so /usr/lib/
fi
#
if [ !  -d /home/ams/bin ]
then
    mkdir -p /home/ams/bin
fi
#
#
cp tof_userapp /home/ams/bin/
chmod 755 -R /home/ams/bin
# change the i2c bus to 1M
sed -i '/dtparam=i2c1_baudrate/d' /boot/config.txt
echo "dtparam=i2c1_baudrate=1000000" >> /boot/config.txt
#
if grep -Fxq "dtparam=i2c0_baudrate=1000000" /boot/config.txt
then
    echo "..."
else
    echo "Append dtparam=i2c0_baudrate=1000000 to /boot/config.txt"
    echo "dtparam=i2c0_baudrate=1000000" >> /boot/config.txt
fi
#
if grep -Fxq "dtoverlay=i2c0-bcm2708,pins_28_29" /boot/config.txt

then
    echo "..."
else
    echo "Append dtoverlay=i2c0-bcm2708,pins_28_29 to /boot/config.txt"
    echo "dtoverlay=i2c0-bcm2708,pins_28_29" >> /boot/config.txt
fi
systemctl daemon-reload
sync
