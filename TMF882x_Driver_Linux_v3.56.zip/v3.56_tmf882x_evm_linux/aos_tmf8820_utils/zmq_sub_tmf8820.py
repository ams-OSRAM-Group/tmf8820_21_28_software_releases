#!/usr/bin/python3

import argparse as ap
import ctypes

addr='169.254.0.2'
port=8083

max_msg_size = 8192
max_num_results = 36
max_bins = 256
max_tdc = 5
max_ch = 2 * max_tdc

class Tmf8820_msg_header(ctypes.Structure):
    _fields_ = [
            ('id', ctypes.c_int),
            ('len', ctypes.c_int),
    ]

class Tmf8820_msg_error(ctypes.Structure):
    _fields_ = [
            ('hdr', Tmf8820_msg_header),
            ('error_code', ctypes.c_int),
    ]

class Tmf8820_meas_result(ctypes.Structure):
    _fields_ = [
            ('confidence', ctypes.c_int),
            ('distance_mm', ctypes.c_int),
            ('channel', ctypes.c_int),
            ('ch_target_idx', ctypes.c_int),
            ('sub_capture', ctypes.c_int),
    ]

class Tmf8820_msg_meas_results(ctypes.Structure):
    _fields_ = [
            ('hdr', Tmf8820_msg_header),
            ('result_num', ctypes.c_int),
            ('temperature', ctypes.c_int),
            ('ambient_light', ctypes.c_int),
            ('photon_count', ctypes.c_int),
            ('ref_photon_count', ctypes.c_int),
            ('sys_ticks', ctypes.c_int),
            ('valid_results', ctypes.c_int),
            ('num_results', ctypes.c_int),
            ('results', Tmf8820_meas_result * max_num_results),
    ]

class Tmf8820_msg_meas_stats(ctypes.Structure):
    _fields_ = [
            ('hdr', Tmf8820_msg_header),
            ('capture_num', ctypes.c_int),
            ('sub_capture', ctypes.c_int),
            ('tdcif_status', ctypes.c_int),
            ('iterations_configured', ctypes.c_int),
            ('remaining_iterations', ctypes.c_int),
            ('accumulated_hits', ctypes.c_int),
            ('raw_hits', ctypes.c_int * max_tdc),
            ('saturation_cnt', ctypes.c_int * max_tdc),
    ]

class Tmf8820_msg_histogram(ctypes.Structure):
    _fields_ = [
            ('hdr', Tmf8820_msg_header),
            ('capture_num', ctypes.c_int),
            ('sub_capture', ctypes.c_int),
            ('histogram_type', ctypes.c_int),
            ('num_tdc', ctypes.c_int),
            ('num_bins', ctypes.c_int),
            ('bins', (ctypes.c_int * max_bins) * max_tdc),
    ]

class Tmf8820_msg(ctypes.Union):
    _fields_ = [
            ('hdr', Tmf8820_msg_header),
            ('err_msg', Tmf8820_msg_error),
            ('hist_msg', Tmf8820_msg_histogram),
            ('meas_result_msg', Tmf8820_msg_meas_results),
            ('meas_stat_msg', Tmf8820_msg_meas_stats),
            ('msg_buf', ctypes.c_byte * max_msg_size),
    ]
    def __new__(cls, buf):
        data = bytearray(buf) + bytearray([0] * max_msg_size)
        return cls.from_buffer_copy(data)
    def __init__(self, buf):
        pass

parser = ap.ArgumentParser(description='''
        Connect to AMS data_publisher IP address and print data.

        Requires packages:
            zmq
            matplotlib
        ''')
parser.add_argument('--hist', default=False, action='store_true', help='Print the histograms')
parser.add_argument('--plot', default=False, action='store_true', help='Plot the histograms')
parser.add_argument('--addr', '-a', default=addr, help='IP address of Raspberry Pi ToF Lib running (default: 169.254.0.2)')
args = parser.parse_args()

URI = "tcp://{}:{}".format(args.addr, port)
print("Connecting to Publisher socket: {}\n".format(URI))

import zmq

# Connect with zmq
ctx = zmq.Context()
sub = ctx.socket(zmq.SUB)
sub.setsockopt(zmq.SUBSCRIBE, b"")
sub.connect(URI)

# Prepare plots
if args.plot:
	import matplotlib.pyplot as plt
	plt.ion()
	fig, histgraph = plt.subplots(3, 3, sharex=True)
	plt.show(block=False)

while True:
    msg = Tmf8820_msg(sub.recv())
    print("\n")
    print("id: {}\tlen: {}".format(msg.hdr.id, msg.hdr.len))

    # Result message
    if msg.hdr.id == 1:
        res = msg.meas_result_msg
        print("results res_num: {}\tnum_res: {}".format(res.result_num,
                                                        res.num_results))
        for r in range(res.valid_results):
            print("ch: {} sub_capture: {} ch_target_idx: {} distance: {}".format(res.results[r].channel,
                                                                                 res.results[r].sub_capture,
                                                                                 res.results[r].ch_target_idx,
                                                                                 res.results[r].distance_mm))

    # Stats message
    if msg.hdr.id == 2:
        stats = msg.meas_stat_msg
        print("stats capture_num: {} acc hits: {}".format(stats.capture_num,
                                                          stats.accumulated_hits))

    # Histogram message
    if msg.hdr.id == 3:
        hist = msg.hist_msg
        print("histograms cap_num: {}\ttype: {}\tnum_tdc: {}\tnum_bins: {N} sub_capture: {S}"
              .format(hist.capture_num, hist.histogram_type, hist.num_tdc,
                      hist.num_tdc - 1, hist.num_bins - 1, N=hist.num_bins,
                      S=hist.sub_capture
                      ))
        if (args.hist):
            for x in range(0,hist.num_tdc):
                print("\nbin[{x}][:128]:\n\t{v0}\nbin[{x}][128:]:\n\t{v1}".format(
                          x=x,
                          v0=hist.bins[x][:128],
                          v1=hist.bins[x][128:],
                          ))
        if (args.plot):
            #clear old plots
            for i in range(3):
                for j in range(3):
                    histgraph[i][j].cla()
			#plot new values
            histgraph[0][0].plot(hist.bins[0][128:])
            histgraph[0][1].plot(hist.bins[1][:128])
            histgraph[0][2].plot(hist.bins[1][128:])
            histgraph[1][0].plot(hist.bins[2][:128])
            histgraph[1][1].plot(hist.bins[2][128:])
            histgraph[1][2].plot(hist.bins[3][:128])
            histgraph[2][0].plot(hist.bins[3][128:])
            histgraph[2][1].plot(hist.bins[4][:128])
            histgraph[2][2].plot(hist.bins[4][128:])
			# set log yaxis
            for i in range(3):
                for j in range(3):
                    histgraph[i][j].set_yscale('log')
            plt.draw()
            plt.pause(0.000001)

        if hist.histogram_type == 1:
            for x in range(hist.num_tdc):
                print("Electrical Calibration TDC[{}] max val: {}".format(x, max(hist.bins[x])))

    # Error message
    if msg.hdr.id == 0xF:
        err = msg.err_msg
        print("ERROR CODE: {}".format(err.error_code))

