// pretty print calibration for Bedwell v1.44
//
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

#define NUMZONES 10

typedef struct
{
    uint32_t uidOfSpadMap;                  // > 0 if initialized
    uint32_t sMapHash;
    uint32_t crosstalkBinQ15[NUMZONES];
    uint32_t crosstalkAmplitude[NUMZONES];
} ONEFACTORYCAL;

typedef struct
{
    uint8_t  pageCheck;        // counter: reset increments
    uint8_t  configRun;        // counter: call to Configure increments
    uint8_t  factCalRun[2];    // counter: factory calibration executed (2 spad maps)
    int8_t   sMapMatched[2];   // spad map/factory cal match
    uint16_t itersK;
    ONEFACTORYCAL cfg[2];
    uint8_t  calibrationStatus;
    uint8_t  unused1;
    uint16_t referenceEC;
} FACTORYCAL;

FACTORYCAL factCal;

int main(int argc, char * argv[])
{
    FILE * fd;
    if (argc > 1)
    {
        fd = fopen(argv[1], "rb");
        if (fd == NULL)
        {
            printf("can't open file\n");
            exit(1);
        }
    }
    else
    {
        fd = freopen(0, "rb", stdin);
    }
    int r = fread((uint8_t *)&factCal, sizeof(factCal), 1, fd);
    size_t fread(void * ptr, size_t size, size_t nmemb, FILE * stream);

    printf("pageCheck %u\nconfigRun %u\nfactCalRun[0] %u factCalRun[1] %u\nsMapMatched[0] %u sMapMatched[1] %u\n",
           factCal.pageCheck & 0xff, factCal.configRun & 0xff, factCal.factCalRun[0] & 0xff, factCal.factCalRun[1] & 0xff,
           factCal.sMapMatched[0] & 0xff, factCal.sMapMatched[1] & 0xff);
    printf("itersK %u\n", factCal.itersK & 0xffff);
    for (int i = 0; i < 2; i++)
    {
        printf("Calibration (configuration %d):\n", i);
        printf("  uidOfSpadMap 0x%08x  sMapHash 0x%08x\n", factCal.cfg[i].uidOfSpadMap, factCal.cfg[i].sMapHash);
        printf("  crosstalks:\n");
        for (int z = 0; z < NUMZONES; z++)
        {
            printf("    z=%d crosstalkBinQ15 %10u (%7.4lf) crosstalkAmplitude %10u\n", z,
                   factCal.cfg[i].crosstalkBinQ15[z],
                   factCal.cfg[i].crosstalkBinQ15[z] / 32768.0,
                   factCal.cfg[i].crosstalkAmplitude[z]);
        }

    }
    printf("calibrationStatus = 0x%x\n", factCal.calibrationStatus);
    printf("unused1 = %d\n", factCal.unused1);
    printf("referenceEC = %d\n", factCal.referenceEC);

    fclose(fd);
}

