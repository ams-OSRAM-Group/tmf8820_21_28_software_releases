
#include <stdio.h>


typedef unsigned int uint32_t;


#define CLOCK__enable_500khz_mode__WIDTH 1
#define CP_CFG__cp_vdd_hvchp__WIDTH 7
#define TDCIF_CONFIG__cp_stops_tdc__WIDTH 1
#define TDCIF_CONFIG__vcdrvcp_stops_tdc__WIDTH 1
#define TDCIF_CONFIG__tdc_start_delay__WIDTH 5
#define TDCIF_CONFIG__tdc_start_shift__WIDTH 4
#define TDCIF_CONFIG__accuhits_threshold__WIDTH 5
#define TDCIF_TRIM_QUENCH__trim_quench__WIDTH 6
#define TDCIF_TRIM_QUENCH__trim_quench_ref_b5__WIDTH 1
#define TDCIF_TRIM_QUENCH__trim_quench_fl_b5__WIDTH 1


typedef union
{
    struct  
    {
        uint32_t useLowPowerOscillator:CLOCK__enable_500khz_mode__WIDTH;                /*!< 500KHz modein standby timed */
        uint32_t spadChargePump:CP_CFG__cp_vdd_hvchp__WIDTH;                            /*!< SPAD charge pump value (not really part of the TDCIF - but that is the best place I found ) */ 
        uint32_t cpStopsTdc:TDCIF_CONFIG__cp_stops_tdc__WIDTH;                          /*!< tdc stops on SPAD charge pump overload */
        uint32_t vcDrvCpStopsTdc:TDCIF_CONFIG__vcdrvcp_stops_tdc__WIDTH;                /*!< tdc stops on VCSEL driver charge pump overload */
        uint32_t tdcStartDelay:TDCIF_CONFIG__tdc_start_delay__WIDTH;                    /*!< shift in delay blocks (one block is ~ 85ps, except first which is larger due to different path) in addition to tdcStartShift */
        uint32_t tdcStartShift:TDCIF_CONFIG__tdc_start_shift__WIDTH;                    /*!< see table above for values, 0 = no shift, shift in m ~( 0.47 * value), or time ( 3.125 ns * value ) - note that light has to travel to and from the object back  */
        uint32_t accuHitsThreshold:TDCIF_CONFIG__accuhits_threshold__WIDTH;             /*!< 0=disable, 1K, 2K, 4K, ... 4G */   
        uint32_t mainSpadDeadTime:TDCIF_TRIM_QUENCH__trim_quench__WIDTH;                /*!< main spad dead time (5 bits) */
        uint32_t referenceSpadDeadTime:TDCIF_TRIM_QUENCH__trim_quench_ref_b5__WIDTH;    /*!< reference spad dead time (5 bits). This is only the MSB, the other 4 are the same as the 4 LSB of hte main spad dead time */
        uint32_t flickerSpadDeadTime:TDCIF_TRIM_QUENCH__trim_quench_fl_b5__WIDTH;       /*!< flicker spad dead time (5 bits). This is only the MSB, the other 4 are the same as the 4 LSB of hte main spad dead time */
    } b;
    uint32_t w;
} tmf8x2xHalTdcIfConfig;

tmf8x2xHalTdcIfConfig tdcif;

void main()
{
	FILE *fp;

	tdcif.b.useLowPowerOscillator = 0;
	tdcif.b.spadChargePump = 0;
	tdcif.b.cpStopsTdc = 1;
	tdcif.b.vcDrvCpStopsTdc = 1;
	tdcif.b.tdcStartDelay = 0;
	tdcif.b.tdcStartShift = 0;
	tdcif.b.accuHitsThreshold = 0;
	tdcif.b.mainSpadDeadTime = 0x07;
	tdcif.b.referenceSpadDeadTime = 0x01;
	tdcif.b.flickerSpadDeadTime = 0;

	printf(" TDCIF CFG  %x  \n", tdcif.w);

    fp = fopen("//sys//devices//platform//soc//20804000.i2c//i2c-1//1-0041//app//tdcif_cfg","wb");
        if(fp!=NULL) {
	    fwrite( &tdcif.w,sizeof(tdcif),1,fp);
	    fclose(fp);
	} else {
		printf("cannot open file\n");
	}

	return;
}


