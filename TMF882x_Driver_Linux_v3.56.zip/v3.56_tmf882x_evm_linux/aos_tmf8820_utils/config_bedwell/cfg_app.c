
#include <stdio.h>

typedef unsigned int uint32_t;
typedef signed int   int32_t;
typedef unsigned short uint16_t;
typedef signed char  int8_t;
typedef unsigned char  uint8_t;


#define TMF8X2X_APP_GPIO_MAX_NUMBER             2       /*!< tmf8x2x has only two gpios that are supported */
#define TMF8X2X_MAX_CONFIGURATIONS                  2 

typedef struct _tmf8x2xComAppConfig
{
    uint32_t periodInMicroSeconds;                      /*!< period is driven by timer3 == cyclic timer which runs with 0.2 microseconds */
    uint16_t electricalCalibrationIterations;           /*!< electrical calibration requires much less iterations */
    uint16_t thresholdLow;                              /*!< lower level threshold - set to 0 to ignore */
    uint16_t thresholdHigh;                             /*!< upper level threshold - set to 0xFFFF to ignore */
    uint8_t bdvCalculationMode;                         /*!< which mode shall be used for BDV calculation */
    uint8_t powerConfig;                                /*!< see above masks to configure power options */
    uint8_t gpioConfig[ TMF8X2X_APP_GPIO_MAX_NUMBER ];  /*!< see above masks for GPIO */
    uint8_t algorithmSetting;                           /*!< algorithm specific setting */
    uint8_t zoneInfo[ (TMF8X2X_MAX_CONFIGURATIONS) ];   /*!< select one of the zone-options - this defines the SPAD mask you selected - see tmf8x2x_app_spad_select_masks.h */
} tmf8x2xComAppConfig;

tmf8x2xComAppConfig appcfg;


void main()
{
	FILE *fp;

	appcfg.periodInMicroSeconds = 30000;
	appcfg.electricalCalibrationIterations = 10000;
	appcfg.thresholdLow =0;
	appcfg.thresholdHigh = 65535;
	appcfg.bdvCalculationMode = 0x00;
	appcfg.powerConfig = 0x20;
	appcfg.gpioConfig[0] = 0;
	appcfg.gpioConfig[1] = 0;
	appcfg.algorithmSetting = 0;
	appcfg.zoneInfo[0] =0;
	appcfg.zoneInfo[1] = 0;
	
	printf(" APP CFG  \n" );

    fp = fopen("//sys//devices//platform//soc//20804000.i2c//i2c-1//1-0041//app//app_cfg","wb");
        if(fp!=NULL) {
	    fwrite( &appcfg,sizeof(appcfg),1,fp);
	    fclose(fp);
	} else {
		printf("cannot open file\n");
	}

	return;
}


