
#include <stdio.h>

typedef unsigned int uint32_t;
typedef signed int   int32_t;
typedef unsigned short uint16_t;
typedef signed char  int8_t;
typedef unsigned char  uint8_t;


typedef struct _tmf8x2xHalReferenceSpadConfig
{
    uint32_t enableSpad;    /*!< 17..0 set to 0 to disable, 1 to enable */
    uint16_t channelMask;   /*!< select tdc channel 0..9 if corresponding bit is set. Note that reference SPAD can therefore be assigned to more than 1 channel */
} tmf8x2xHalReferenceSpadConfig;


tmf8x2xHalReferenceSpadConfig refspad;

void main()
{
	FILE *fp;

	refspad.enableSpad = 0xFFFF;
	refspad.channelMask = 0x01;
	printf(" Ref SPAD CFG  %x %x\n", refspad.enableSpad, refspad.channelMask);

    fp = fopen("//sys//devices//platform//soc//20804000.i2c//i2c-1//1-0041//app//ref_spad_cfg","wb");
        if(fp!=NULL) {
	    fwrite( &refspad,sizeof(refspad),1,fp);
	    fclose(fp);
	} else {
		printf("cannot open file\n");
	}

	return;
}

