
#include <stdio.h>

typedef unsigned int uint32_t;
typedef signed int   int32_t;
typedef unsigned short uint16_t;
typedef signed char  int8_t;
typedef unsigned char  uint8_t;

#define TMF8X2X_MAIN_SPAD_MAX_X_SIZE                 (18)                    /* maximum amount of SPAD selected in one ROW */
#define TMF8X2X_MAIN_SPAD_MAX_Y_SIZE                 (10)                    /* maximum amount of SPAD selected in one column */
#define TMF8X2X_MAIN_SPAD_ROWS                       18
#define TMF8X2X_MAIN_SPAD_COLUMNS                    34
#define TMF8X2X_MAIN_SPAD_CONFIG_OK              0
#define TMF8X2X_MAIN_SPAD_CONFIG_ERR_PARAM       -1  /* one of the input parameter is either a 0-pointer, or the sizes are too big */            
#define TMF8X2X_MAIN_SPAD_CONFIG_ERR_ROW_01_89   -2  /* cannot mix channels 0/1 and channels 8/9 in same row */

/*!< to encode a single channel, we need to set 3 bits at specific positions in the 32-bit word */
#define TMF8X2X_MAIN_SPAD_ENCODE_CHANNEL( channel, yPosition )                                                       \
        ( ( ( ( (channel) & 1 /*LSB*/ )      ) << ( (TMF8X2X_MAIN_SPAD_VERTICAL_LSB_SHIFT) + (yPosition) ) )         \
        | ( ( ( (channel) & 2 /*Mid*/ ) >> 1 ) << ( (TMF8X2X_MAIN_SPAD_VERTICAL_MID_SHIFT) + (yPosition) ) )         \
        | ( ( ( (channel) & 4 /*MSB*/ ) >> 2 ) << ( (TMF8X2X_MAIN_SPAD_VERTICAL_MSB_SHIFT) + (yPosition) ) )         \
        )

#define TMF8X2X_MAIN_SPAD_VERTICAL_LSB_SHIFT     ( 0 )
#define TMF8X2X_MAIN_SPAD_VERTICAL_MID_SHIFT     ( 10 )
#define TMF8X2X_MAIN_SPAD_VERTICAL_MSB_SHIFT     ( 20 )
#define TMF8X2X_MAIN_SPAD_VERTICAL_BIT_MASK      ( ( 1 << 10 ) - 1 )

typedef struct _tmf8x2xHalMainSpadConfig
{
    uint32_t enableSpad[ TMF8X2X_MAIN_SPAD_MAX_Y_SIZE ]; /*!< have each bit set for a spad in the FOV that you want to enable */ 
    uint32_t tdcChannel[ TMF8X2X_MAIN_SPAD_MAX_X_SIZE ]; /*!< encoded in one 32-bit word are 3x10bits that encode one column of the selected SPAD */
    uint32_t tdcChannelSelect;  /*!< each row can have selected tdc channels 0/1 or tdc channels 8/9 */
    uint8_t xOffset;    /*!< lower left corner (range is 0..33) */ 
    uint8_t yOffset;    /*!< lower left corner (range is 0..17) */
    uint8_t xSize;      /*!< wide in x-dimension (range is 1..18) */
    uint8_t ySize;      /*!< wide in y-dimension (range is 1..10) */
} tmf8x2xHalMainSpadConfig;

tmf8x2xHalMainSpadConfig mainspad;

int8_t tmf8x2xConfigureMainSpad ( tmf8x2xHalMainSpadConfig * config, uint8_t xOffset, uint8_t yOffset, uint8_t xSize, uint8_t ySize, const uint8_t * channelMap )
{
    int32_t x;
    int32_t y;
    uint16_t lineSelect = 0; /* default all have channel 0/1 selected */
    if (  ! config 
       || ! channelMap
       || ( xOffset >= TMF8X2X_MAIN_SPAD_COLUMNS )
       || ( yOffset >= TMF8X2X_MAIN_SPAD_ROWS )
       || ( xSize > TMF8X2X_MAIN_SPAD_MAX_X_SIZE )
       || ( ySize > TMF8X2X_MAIN_SPAD_MAX_Y_SIZE )
       )
    {
        return TMF8X2X_MAIN_SPAD_CONFIG_ERR_PARAM; /* out of bound error */
    }
    for ( y = 0; y < ySize; y++ ) /* enable all SPAD */
    {
        config->enableSpad[ y ] = ( 1 << xSize ) - 1;
    }
    /* check for correct channel selection (no 0/1 in same row as 8/9) */
    for ( y = 0; y < ySize; y++ )
    {
        int is01; /* so far we do not know */
        int is01Set = 0; /* so far we have neither 0 nor 1 selected */
        const uint8_t * row = channelMap + ( ( ySize - 1 - y ) * xSize ) ; /* step through linear array row wise. So as start-point for inner loop we have to go through lines */
        for ( x = 0; x < xSize; x++ )
        {
            if ( row[ x ] == 0 || row[ x ] == 1 )
            {
                if ( !is01Set ) /* never set for this row - so set it now that we have 0/1 and may not have 8/9 */
                {
                    is01Set = 1;
                    is01 = 0;
                }
                else if ( is01 )
                {
                    return TMF8X2X_MAIN_SPAD_CONFIG_ERR_ROW_01_89;
                }
            }
            else if ( row[ x ] == 8 || row[ x ] == 9 )
            {
                if ( !is01Set ) /* never set for this row - so set it now that we have 8/9 and may not have 0/1 */
                {
                    is01Set = 1;
                    is01 = 1;
                    lineSelect |= ( 1 << y ); /* this row has channels 8/9 selected */
                }
                else if ( ! is01 )
                {
                    return TMF8X2X_MAIN_SPAD_CONFIG_ERR_ROW_01_89;
                }
            }
        }
    }
    
    /* now we can go on to pack the bits per column */
    for ( x = 0; x < xSize; x++ )
    {
        uint32_t encode = 0; /* default is tdc channel 0 for all */
        uint8_t yIdx; /* now we go from bottom up in table, we need to invert the accessing index for y here. If ySize is 0, we won't enter below loop anyhow. */
        for ( y = 0, yIdx = ySize - 1; y < ySize; y++, yIdx-- )
        { 
            uint8_t ch = channelMap[ x + ( yIdx * xSize ) ];    /* in linear array we need to start from bottom */ 
            encode |= TMF8X2X_MAIN_SPAD_ENCODE_CHANNEL( ch, y );/* an 8 is masked out by macro to a 0, and a 9 is masked out by macro to a 1 */
        }
        config->tdcChannel[ x ] = encode;
    }
    
    /* finally set the boundaries correctly in config record, and the row channel line select bits */
    config->xOffset = xOffset;
    config->yOffset = yOffset;
    config->xSize = xSize;
    config->ySize = ySize;
    config->tdcChannelSelect = lineSelect;
    
    return TMF8X2X_MAIN_SPAD_CONFIG_OK;
}


 const uint8_t tmx8x2xSpadChannelMap3x3 [  ] = /* always 20 SPAD for 1 Zone */
        /* x = 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17  */    
/* y =  9 */ { 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3                         
    /*  8 */ , 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3                         
    /*  7 */ , 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3  
    /*  6 */ , 1, 1, 4, 4, 4, 4, 5, 5, 2, 2, 5, 5, 6, 6, 6, 6, 3, 3  
    /*  5 */ , 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6  
    /*  4 */ , 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6  
    /*  3 */ , 7, 7, 4, 4, 4, 4, 5, 5, 8, 8, 5, 5, 6, 6, 6, 6, 9, 9  
    /*  2 */ , 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9  
    /*  1 */ , 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9                           
    /*  0 */ , 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9                          
             };

 const uint8_t tmx8x2xSpadChannelMap1d [  ] = /* always 20 SPAD for 1 Zone */
        /* x = 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17  */    
/* y =  9 */ { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1                     
    /*  8 */ , 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1                     
    /*  7 */ , 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    /*  6 */ , 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    /*  5 */ , 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    /*  4 */ , 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    /*  3 */ , 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    /*  2 */ , 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    /*  1 */ , 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1                       
    /*  0 */ , 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1                      
             };                           


void main()
{
	FILE *fp;

	(void)tmf8x2xConfigureMainSpad ( &mainspad, 0, 0, 18, 10, tmx8x2xSpadChannelMap1d );
	printf(" Main SPAD CFG  \n" );

    fp = fopen("//sys//devices//platform//soc//20804000.i2c//i2c-1//1-0041//app//main_spad_cfg","wb");
        if(fp!=NULL) {
	    fwrite( &mainspad,sizeof(mainspad),1,fp);
	    fclose(fp);
	} else {
		printf("cannot open file\n");
	}

	return;
}



