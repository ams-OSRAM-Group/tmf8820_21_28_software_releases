#include <stdio.h>

#define VCSEL_CFG__vcsel_incr_glow_curr__WIDTH 1
#define VCSEL_CFG__en_vcdrv_shunt_s__WIDTH 1
#define VCSEL_CFG__en_vcdrv_shunt_w__WIDTH 1
#define VCSEL_CFG2__vcsel_pulsewidth__WIDTH 2
#define VCSEL_CFG2__vcsel_ipulse__WIDTH 6
#define VCSEL_CFG3__ss_amplitude__WIDTH 5
#define VCSEL_CFG3__vcsel_ss_rounds__WIDTH 2
#define VCSEL_CFG4__vcsel_start_edge__WIDTH 1
#define VCSEL_CFG5__vcsel_start__WIDTH 4
#define VCSEL_CFG4__vcsel_frame_len__WIDTH 5
#define VCSEL_CFG5__vcsel_length__WIDTH 4
#define VCSEL_CFG__sel_vcdrv_pls_source__WIDTH 1


typedef unsigned int uint32_t;

typedef union
{
    struct
    {
        uint32_t incrGlowCurrent:VCSEL_CFG__vcsel_incr_glow_curr__WIDTH;                                /*!< increase glow current - for BDV only*/
        uint32_t vcselShuntS:VCSEL_CFG__en_vcdrv_shunt_s__WIDTH;                                        /*!< resistor to reduce tail in VCSEL */
        uint32_t vcselShuntW:VCSEL_CFG__en_vcdrv_shunt_w__WIDTH;                                        /*!< resistor to reduce tail in VCSEL */
        uint32_t vcselPulseWidth:VCSEL_CFG2__vcsel_pulsewidth__WIDTH;                                   /*!< VCSEL pulse width - defines the width of the optical pulse */
        uint32_t vcselIPulse:VCSEL_CFG2__vcsel_ipulse__WIDTH;                                           /*!< VCSEL power */
        uint32_t spreadSpectrumAmplitude:VCSEL_CFG3__ss_amplitude__WIDTH;                               /*!< VCSEL spread spectrum amplitute */
        uint32_t spreadSpectrumRounds:VCSEL_CFG3__vcsel_ss_rounds__WIDTH;                               /*!< VCSEL how quickly the pulse modulation changes */
        uint32_t vcselStartShift:(VCSEL_CFG4__vcsel_start_edge__WIDTH+VCSEL_CFG5__vcsel_start__WIDTH);  /*!< To shift the VCSEL pulse start to later in time - usually you will not want to do this. Units is 3.125ns - see table above */
        uint32_t vcselFrameLength:VCSEL_CFG4__vcsel_frame_len__WIDTH;                                   /*!< VCSEL pulse period in FIXME mar what is this really */
        uint32_t vcselPulseLength:VCSEL_CFG5__vcsel_length__WIDTH;                                      /*!< FIXME mar: to be clarified if this is only for external, for external VCSEL, set to 0 for 50:50 duty cycle, else pulse is in 3.125ns steps */

        uint32_t reserved0:31;  
        uint32_t useExternalVcsel:VCSEL_CFG__sel_vcdrv_pls_source__WIDTH;                               /*!< set this to 1 if you want to use an external VCSEL */
    } b;
    uint32_t w[ 2 ];
} tmf8x2xHalVcselConfig;

tmf8x2xHalVcselConfig   vcselCfg;

void main()
{
	FILE *fp;

    vcselCfg.b.incrGlowCurrent =0;
    vcselCfg.b.vcselShuntS =0;
    vcselCfg.b.vcselShuntW =0;
	vcselCfg.b.vcselPulseWidth = 0;
	vcselCfg.b.vcselIPulse = 15;
	vcselCfg.b.spreadSpectrumAmplitude = 0;
	vcselCfg.b.spreadSpectrumRounds = 0;
	vcselCfg.b.vcselStartShift = 0;
	vcselCfg.b.vcselFrameLength = 8;
	vcselCfg.b.vcselPulseLength = 0;
	vcselCfg.b.reserved0 = 0;
	vcselCfg.b.useExternalVcsel =0;
	printf(" VCSEL CFG  %x  %x\n", vcselCfg.w[0], vcselCfg.w[1]);

    fp = fopen("//sys//devices//platform//soc//20804000.i2c//i2c-1//1-0041//app//vcsel_cfg","wb");
        if(fp!=NULL) {
	    fwrite( &vcselCfg.w[0],sizeof(vcselCfg),1,fp);
	    fclose(fp);
	} else {
		printf("cannot open file\n");
	}

	return;
}



#if 0
#define TDC0_CONTROL__powersavingmode__WIDTH 1
#define TDC0_CONFIG__ignore_decoder_error__WIDTH 1
#define TDC0_CONFIG__threshold__WIDTH 5
#define TDC0_CONFIG__bin_shift__WIDTH 2
#define TDC0_CONFIG__div_by_3__WIDTH 1
#define TDC0_CONFIG__dual_mode__WIDTH 1
#define TDC0_CALIB__sel_calib_sig__WIDTH 4
#define TDC0_SEGMENT1__hist_segment1__WIDTH 9
#define TDC0_SEGMENT2__hist_segment2__WIDTH 9

typedef union
{ 
    struct  
    {
        uint32_t reserved0:12;                                                  /*!< unused */
        uint32_t useTdcIfCalib:1;                                               /*!< this is a selection bit to select either the internal TDC signals for calibration of teh external ones */
        uint32_t powerSaving:TDC0_CONTROL__powersavingmode__WIDTH;         		/*!< set this to 1 to save some power in the TDC */
        uint32_t ignoreDecoderError:TDC0_CONFIG__ignore_decoder_error__WIDTH;  	/*!< set to 0 normally, just in case we have many decoder erros this can help */
        uint32_t binThreshold:TDC0_CONFIG__threshold__WIDTH;                    /*!< 4, 8, 16, ... 16m */
        uint32_t binShift:TDC0_CONFIG__bin_shift__WIDTH;                        /*!< 0, 1, 2, 3 */
        uint32_t divBy3:TDC0_CONFIG__div_by_3__WIDTH;                           /*!< after applying bin shift, divide result by 3 */
        uint32_t dualMode:TDC0_CONFIG__dual_mode__WIDTH;                        /*!< 1 = dual, 0 = standard */
        uint32_t calibEdge1:TDC0_CALIB__sel_calib_sig__WIDTH;                   /*!< calibration edge 1 - set to value greater than 7 to ignore it */
        uint32_t calibEdge2:TDC0_CALIB__sel_calib_sig__WIDTH;          			/*!< calibration edge 2 - set to value greater than 7 to ignore it */
		uint32_t reserved1:14;
		uint32_t segment1:TDC0_SEGMENT1__hist_segment1__WIDTH;			        /*!< double bin-size after this bin (until segment2) */
		uint32_t segment2:TDC0_SEGMENT2__hist_segment2__WIDTH;			        /*!< double bin-size after this bin again */
    } b;
    uint32_t w[ 2 ]; 
} tmf8x2xHalTdcConfig;


#define CLOCK__enable_500khz_mode__WIDTH 1
#define CP_CFG__cp_vdd_hvchp__WIDTH 7
#define TDCIF_CONFIG__cp_stops_tdc__WIDTH 1
#define TDCIF_CONFIG__vcdrvcp_stops_tdc__WIDTH 1
#define TDCIF_CONFIG__tdc_start_delay__WIDTH 5
#define TDCIF_CONFIG__tdc_start_shift__WIDTH 4
#define TDCIF_CONFIG__accuhits_threshold__WIDTH 5
#define TDCIF_TRIM_QUENCH__trim_quench__WIDTH 6
#define TDCIF_TRIM_QUENCH__trim_quench_ref_b5__WIDTH 1
#define TDCIF_TRIM_QUENCH__trim_quench_fl_b5__WIDTH 1


typedef union
{
    struct  
    {
        uint32_t useLowPowerOscillator:CLOCK__enable_500khz_mode__WIDTH;                /*!< 500KHz modein standby timed */
        uint32_t spadChargePump:CP_CFG__cp_vdd_hvchp__WIDTH;                            /*!< SPAD charge pump value (not really part of the TDCIF - but that is the best place I found ) */ 
        uint32_t cpStopsTdc:TDCIF_CONFIG__cp_stops_tdc__WIDTH;                          /*!< tdc stops on SPAD charge pump overload */
        uint32_t vcDrvCpStopsTdc:TDCIF_CONFIG__vcdrvcp_stops_tdc__WIDTH;                /*!< tdc stops on VCSEL driver charge pump overload */
        uint32_t tdcStartDelay:TDCIF_CONFIG__tdc_start_delay__WIDTH;                    /*!< shift in delay blocks (one block is ~ 85ps, except first which is larger due to different path) in addition to tdcStartShift */
        uint32_t tdcStartShift:TDCIF_CONFIG__tdc_start_shift__WIDTH;                    /*!< see table above for values, 0 = no shift, shift in m ~( 0.47 * value), or time ( 3.125 ns * value ) - note that light has to travel to and from the object back  */
        uint32_t accuHitsThreshold:TDCIF_CONFIG__accuhits_threshold__WIDTH;             /*!< 0=disable, 1K, 2K, 4K, ... 4G */   
        uint32_t mainSpadDeadTime:TDCIF_TRIM_QUENCH__trim_quench__WIDTH;                /*!< main spad dead time (5 bits) */
        uint32_t referenceSpadDeadTime:TDCIF_TRIM_QUENCH__trim_quench_ref_b5__WIDTH;    /*!< reference spad dead time (5 bits). This is only the MSB, the other 4 are the same as the 4 LSB of hte main spad dead time */
        uint32_t flickerSpadDeadTime:TDCIF_TRIM_QUENCH__trim_quench_fl_b5__WIDTH;       /*!< flicker spad dead time (5 bits). This is only the MSB, the other 4 are the same as the 4 LSB of hte main spad dead time */
    } b;
    uint32_t w;
} tmf8x2xHalTdcIfConfig;

#endif

