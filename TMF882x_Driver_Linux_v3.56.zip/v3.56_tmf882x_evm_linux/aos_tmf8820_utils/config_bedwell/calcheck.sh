#!/bin/bash
#
#    be sure to compile and copy
#         cd /home/ams/v2.28_tmf8820_evm_linux/aos_tmf8820_utils/config_bedwell/
#         gcc ppcal -o ppcal
#         cp ppcal /home/ams/
#
#   the following directory might vary:
#   (also do "sudo su" before running this)
#
cd /sys/devices/platform/soc/20804000.i2c/i2c-1/1-0041/app
cat calibration_data | /home/ams/ppcal
cat ../registers | grep 0x04
