
#include <stdio.h>

#define TDC0_CONTROL__powersavingmode__WIDTH 1
#define TDC0_CONFIG__ignore_decoder_error__WIDTH 1
#define TDC0_CONFIG__threshold__WIDTH 5
#define TDC0_CONFIG__bin_shift__WIDTH 2
#define TDC0_CONFIG__div_by_3__WIDTH 1
#define TDC0_CONFIG__dual_mode__WIDTH 1
#define TDC0_CALIB__sel_calib_sig__WIDTH 4
#define TDC0_SEGMENT1__hist_segment1__WIDTH 9
#define TDC0_SEGMENT2__hist_segment2__WIDTH 9

typedef unsigned int uint32_t;

typedef union
{ 
    struct  
    {
        uint32_t reserved0:12;                                                  /*!< unused */
        uint32_t useTdcIfCalib:1;                                               /*!< this is a selection bit to select either the internal TDC signals for calibration of teh external ones */
        uint32_t powerSaving:TDC0_CONTROL__powersavingmode__WIDTH;         		/*!< set this to 1 to save some power in the TDC */
        uint32_t ignoreDecoderError:TDC0_CONFIG__ignore_decoder_error__WIDTH;  	/*!< set to 0 normally, just in case we have many decoder erros this can help */
        uint32_t binThreshold:TDC0_CONFIG__threshold__WIDTH;                    /*!< 4, 8, 16, ... 16m */
        uint32_t binShift:TDC0_CONFIG__bin_shift__WIDTH;                        /*!< 0, 1, 2, 3 */
        uint32_t divBy3:TDC0_CONFIG__div_by_3__WIDTH;                           /*!< after applying bin shift, divide result by 3 */
        uint32_t dualMode:TDC0_CONFIG__dual_mode__WIDTH;                        /*!< 1 = dual, 0 = standard */
        uint32_t calibEdge1:TDC0_CALIB__sel_calib_sig__WIDTH;                   /*!< calibration edge 1 - set to value greater than 7 to ignore it */
        uint32_t calibEdge2:TDC0_CALIB__sel_calib_sig__WIDTH;          			/*!< calibration edge 2 - set to value greater than 7 to ignore it */
		uint32_t reserved1:14;
		uint32_t segment1:TDC0_SEGMENT1__hist_segment1__WIDTH;			        /*!< double bin-size after this bin (until segment2) */
		uint32_t segment2:TDC0_SEGMENT2__hist_segment2__WIDTH;			        /*!< double bin-size after this bin again */
    } b;
    uint32_t w[ 2 ]; 
} tmf8x2xHalTdcConfig;

tmf8x2xHalTdcConfig   tdccfg;

void main()
{
	FILE *fp;

    tdccfg.b.useTdcIfCalib = 0;
	tdccfg.b.powerSaving = 0;
	tdccfg.b.ignoreDecoderError = 0;
	tdccfg.b.binThreshold = 31;
	tdccfg.b.binShift = 1;
	tdccfg.b.divBy3 = 0;
	tdccfg.b.dualMode = 1;
	tdccfg.b.calibEdge1 = 1;
	tdccfg.b.calibEdge2 = 3;
	tdccfg.b.segment1 = 511;
	tdccfg.b.segment2 = 511;
	printf(" TDC CFG  %x  %x\n", tdccfg.w[0], tdccfg.w[1]);

    fp = fopen("//sys//devices//platform//soc//20804000.i2c//i2c-1//1-0041//app//tdc_cfg","wb");
        if(fp!=NULL) {
	    fwrite( &tdccfg.w[0],sizeof(tdccfg),1,fp);
	    fclose(fp);
	} else {
		printf("cannot open file\n");
	}

	return;
}

