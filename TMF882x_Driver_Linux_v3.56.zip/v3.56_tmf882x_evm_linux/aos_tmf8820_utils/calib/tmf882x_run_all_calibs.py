#!/usr/bin/env python3
# Tool to connect to TMF882X EVM and run all calibration commands in sequence
# For calibration physical setup see datasheet - needs EVM Version 3.3.31.0 for operation
# Output of calibration is stored in calib_<device-id>.csv
# 
# *****************************************************************************
# * Copyright by ams AG                                                       *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED FOR USE ONLY IN CONJUNCTION WITH AMS PRODUCTS.  *
# * USE OF THE SOFTWARE IN CONJUNCTION WITH NON-AMS-PRODUCTS IS EXPLICITLY    *
# * EXCLUDED.                                                                 *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     *
# * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
#
# Version 1v8-1
# ptr / 6.Mai 2021
#
import socket
import numpy as np
import tmf8828_get_all_histograms_in_8x8_mode_zmq as tmf8828
import re
from time import sleep

# Parameters for Analysis
xtalk_max_3x3 = 15200          # from ODG for TMF882X
xtalk_min_3x3 = 900            # from ODG for TMF882X
xtalk_max_4x4 = 16000          # from ODG for TMF882X
xtalk_min_4x4 = 900            # from ODG for TMF882X
xtalk_max_8x8 = 6360           # from ODG for TMF882X
xtalk_min_8x8 = 320            # from ODG for TMF882X
xtalk_no_object_dist = 400     # no object within 400mm from ODG for TM882X
xtalk_ambient_max = 200        # maximum ambient light; needs to be much lower than xtalk_min for a correct measurement

tof_id = None # tof unique ID
log = []

def get_data_from_ZMQ():
    zmqSocket = tmf8828.connectToRaspi()
    logstring, _ = tmf8828.getAllHistogramsIn8x8Mode( zmqSocket, do_function = tmf8828.calc_crosstalk)
    zmqSocket.close()
    return logstring

def get_data_from_EVM_GUI(sock, cmd = None, channels = 9) -> (str, int, int, int, int):
    '''Process information from TMF882X EVM GUI and extract data as needed
    
    sock -- an open socket for the connection to the EVM GUI; connection errors need to be handled in calling function
    
    return value: (description, xtalk)
    string description -- a textual description for displaying the result or any error
    int xtalk -- integer with amount of crosstalk; returns 0 in case of error
    int background -- the amount of background light, should be much lower than xtalk
    int iterations -- number of iterations for this measurement
    obj -- object data; array of integers of distance / confidence for each ch
    '''
    xtalk = [0]*80  # initialize
    background = [0]*80
    iterations = 0
    obj = None  # initialize
    is_8x8 = (channels == 64)
    if cmd:
        if is_8x8:
            # strip Spad Map setting which is unsupported in 8x8
            cmd = re.sub(r'\(S\d\)', '', cmd.decode(), re.I).encode()
        sock.sendall(cmd)  # run command
    while True:
        try:
            if is_8x8:
                s = get_data_from_ZMQ()
            else:
                s = str(sock.recv(20000), 'utf-8')
            s = s.replace('\r\n', '\n')
            entries = s.split('\n') # we could have read several lines, so process them one by one
            for item in entries:
                try:
                    data = item.split(';')
                    log.append(data)
                    #print(data)
                    if data[0] == '#VER':
                        global tof_id
                        #tof_id = f'ToF ID {data[1]} - App {data[2]} - Drv {data[3]}'
                        tof_id = data[1]
                    if data[0][0:6] == '#HLONG' or '#HIST' in data[0]:  # histograms
                        # do whatever needs to be done with histograms... only an example is shown below
                        entry = re.search(r'\d', data[0])
                        if entry is None:
                            continue
                        entry = int(data[0][entry.start():]) # which histogram?
                        pt_hist = [int(x) for x in data[1:]]  # convert to int list
                        xtalk[entry] = max(pt_hist[5:20])  # search for the crosstalk peak
                        # background light calculation: max(avg bins 0-7)
                        background[entry] = int(sum(pt_hist[0:8])/8) # limit it to int
                    if data[0] == '#OBJ':  # OBJ is always the last entry
                        obj = [int(x) for x in data[5:]]  # convert to int list removing other information
                    if data[0] == '#ITT':  # iterations
                        iterations = int(data[2])
                except (ValueError, IndexError) as e:
                    pass  # to ignore header lines as they raise an exception if converted to int()
        except socket.timeout:
            background = background[1:channels+1]  # remove reference channel and unused channels
            xtalk =      xtalk[1:channels+1]       # remove reference channel and unused channels
            return (f'XTalk {xtalk} BG {background}', xtalk, background, iterations, obj)
        if is_8x8:
            background = background[1:channels+1]  # remove reference channel and unused channels
            xtalk =      xtalk[1:channels+1]       # remove reference channel and unused channels
            return (f'XTalk {xtalk} BG {background}', xtalk, background, iterations, obj)

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    host = "localhost"  # the EVM GUI should be run on the same computer
    port = 39998  # ToF EVM Automation port
    print('Connecting to EVM')
    sock.connect((host, port))
    sock.settimeout(2)  # 2s timeout
    # first get headers and version number
    description, xtalk, background, iterations, obj = get_data_from_EVM_GUI(sock)
    response = get_data_from_EVM_GUI(sock)
    if not tof_id:
        print('No ToF ID received - stopping')
        input('Press enter to quit')
    else:
        print('TMF882X ID ' + tof_id)
        # have to do a dummy measurement otherwise sometime #HLONG09 will have no data
        description, xtalk, background, iterations, obj = get_data_from_EVM_GUI(sock, cmd=f'(P0)\n\r(S0)\n\r(i550)\n\r(H3)\n\r(m0)'.encode())
        error = '' # initialize
        # configure settings and run first measurement with 550k iterations - i550, Pixel 3x3 - P0, first SPAD map - S0
        for mode, setting, channels, xtalk_min, xtalk_max in [['3X3', 'P0',  9, xtalk_min_3x3, xtalk_max_3x3], 
                                                              ['4X4', 'P1', 16, xtalk_min_4x4, xtalk_max_4x4],
                                                              ['8X8', 'P3', 64, xtalk_min_8x8, xtalk_max_8x8]]:
            background_list = []
            xtalk_list = []
            # make setting first
            for i in range(2):  # do it twice - don't know why it sometimes fails
                get_data_from_EVM_GUI(sock, cmd=f'({setting})\n\r(S0)\n\r(H3)\n\r(i550)'.encode())
            for i in range(5):
                print('.'*(i+1), end='\r')
                description, xtalk, background, iterations, obj = get_data_from_EVM_GUI(sock, cmd=f'(m0)'.encode(),
                                                                                        channels = channels)
                xtalk_list.append(xtalk)
                background_list.append(background)
            # calculate average
            xtalk = (np.sum(xtalk_list, 0) / len(xtalk_list)).astype(int)
            background = (np.sum(background_list, 0) / len(background_list)).astype(int)
            description = f'XTalk {xtalk} BG {background}'.replace('\n', '')
            print(mode + " mode " + description)
            # add calcualted results to log file
            log.append(['#DESCRIPTION' + mode, description])
            d = ['#BKGD', mode]
            d.extend(map(str, background))
            log.append(d)
            d = ['#XTALK', mode]
            d.extend(map(str, xtalk))
            log.append(d)

            # now run all the checks
            min_xtalk = min(xtalk)
            max_xtalk = max(xtalk)
            ambient = max(background)
            objs = np.array(obj[0:-1:4] + [5000]) # add 5000mm if there is no object found
            closest_target = min(objs[objs>0])    # closest non-zero distance
            if closest_target < xtalk_no_object_dist:
                error = error + f'{mode} Target {closest_target}mm too close (min {xtalk_no_object_dist}mm)\n'
            if min_xtalk < xtalk_min:
                error = error + f'{mode} Crosstalk min {min_xtalk} too low (<{xtalk_min})\n'
            if max_xtalk > xtalk_max:
                error = error + f'{mode} Crosstalk max {max_xtalk} too high (>{xtalk_max})\n'
            if ambient > xtalk_ambient_max:
                error = error + f'{mode} Ambient {ambient} too high (>{xtalk_ambient_max})\n'

        if not error == '':
            print('ERROR')
            print(error)
            for i in error.split('\n')[:-1]:
                log.append(['#ERR', i])
            input('Press enter to confirm and ignore error')

        # change back to 3x3 mode with 550k iterations
        get_data_from_EVM_GUI(sock, cmd=f'(P0)\n\r(S0)\n\r(H3)\n\r(i550)\n\r(m0)'.encode())

        # now iterate through calibration items
        spad_masks_per_mode = [6, 4, 1, 1] # 3x3 has 6 spad masks, 4x4 has 4, 3x6 has 1, 8x8 has 1
        for short_range in range(2):
            for mode in range(4):
                for spad_mask in range(spad_masks_per_mode[mode]):
                    print(f'Calibrating mode {mode}, spad mask {spad_mask}, short_range {short_range}')
                    log.append(['#CALIBRATING', f'mode={mode}', f'spad_mask={spad_mask}',
                               f'short_range={short_range}'])
                    # set the mode first
                    get_data_from_EVM_GUI(sock, cmd=f'(P{mode})'.encode())
                    sleep(1)
                    # set config and do 1 measurement
                    if mode == 3:
                        get_data_from_EVM_GUI(sock, cmd=f'(R{short_range})\r\n(i4000)'.encode())
                    else:
                        get_data_from_EVM_GUI(sock, cmd=f'(S{spad_mask})\n\r(R{short_range})\r\n(i4000)'.encode())
                    sleep(1)
                    # do 1 measurement to commit settings
                    get_data_from_EVM_GUI(sock, cmd=f'(H0)\n\r(m0)'.encode())
                    sleep(1)
                    # do calib
                    get_data_from_EVM_GUI(sock, cmd=f'\n\r(C0)'.encode())
                    sleep(1)
        # change back to 3x3 mode with 550k iterations
        get_data_from_EVM_GUI(sock, cmd=f'(P0)\n\r(S0)\n\r(H3)\n\r(i550)\n\r(m0)'.encode())
        # now output logfile
        with open(f'calib_{tof_id}.csv', 'w') as f:
            print('sep=;', file=f)
            for i in log[1:]:
                if not i == ['']: # do not output empty lines.
                    print(';'.join(i), file=f)

    sock.close()

except socket.error as e:
    print(f'Please start TMF882X EVM GUI and connect TMF882X before starting this script - Connection Error: {e}')
    input('Press enter to quit')


