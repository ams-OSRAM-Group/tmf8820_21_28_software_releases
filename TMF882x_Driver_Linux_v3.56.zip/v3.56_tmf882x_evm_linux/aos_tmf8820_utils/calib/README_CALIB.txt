# Calibration script

The calibration script is implemented in Python and connects to the EVM and
runs through all of the spad configurations of the device and runs the
factory calibration routine. The factory calibration data is saved in the
EVM and persists through power-cycles.


## Prerequisites

- Must be run on the PC that the EVM is connected
- EVM GUI must be version 4.4.7 or later
- EVM GUI must be running
- EVM version must be v3.32 or later
- PC must have python 3.x installed
    - python must have `pyzmq` installed
    - python must have `numpy` installed

## Crosstalk check
The calibration script checks the crosstalk values in the histograms from the
different spad configurations and checks the crosstalk values. If the crosstalk
values are out-of-specification, an error is printed and the user can
optionally force the calibration to continue.
