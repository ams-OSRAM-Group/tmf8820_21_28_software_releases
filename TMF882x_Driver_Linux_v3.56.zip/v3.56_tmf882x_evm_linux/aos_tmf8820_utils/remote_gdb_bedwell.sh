target extended-remote | ssh -T root@10.20.91.61 gdbserver --multi -
set remote exec-file /home/ams/bin/tof_userapp
file ./out/arm/bin/tof_userapp
start
set solib-search-path ./out/arm/lib/
