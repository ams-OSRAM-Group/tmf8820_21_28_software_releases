#ifndef TMF8828_IMAGE_H
#define TMF8828_IMAGE_H

extern const unsigned long tmf8828_image_termination;
extern const unsigned long tmf8828_image_start;
extern const unsigned long tmf8828_image_finish;
extern const unsigned long tmf8828_image_length;
extern const unsigned char tmf8828_image[];

#endif /* TMF8828_IMAGE_H */
